﻿# Get script parameters ( if any )
[CmdletBinding()]
param(
	[parameter(Mandatory = $false, HelpMessage = "Silent")]
	[Switch]$Force,
	[string]$secure_password
)

# Exclude files or directories from compressed packages
$ArchiveExclude = @(
	"-x!themes\Release"
	"-x!themes\docs"
	"-x!themes\downloads"
)

# Compressed package name
$CPname = "lang-php-latest-master"

# Save the compressed package to
$CPSaveTo = "$PSScriptRoot\Release"

# Archive temporary directory
$TempFolder = "$env:userprofile\Downloads\Temp.$CPname"

function Set-Password {
	Write-Host "`n  Please enter the PGP security password!`n" -ForegroundColor Green
	$script:secure_password = read-host "  Certificate password"
	Write-Host ""
}

function Wait-Exit {
	param(
		[int]$wait
	)
	Write-Host "`n   Tip: The script will automatically exit after $wait seconds..." -ForegroundColor Red
	Start-Sleep -s $wait
	exit
}

function Get-Zip {
	if (Test-Path "$env:ProgramFiles\7-Zip\7z.exe") {
		$script:Zip = "$env:ProgramFiles\7-Zip\7z.exe"
		return
	}

	if (Test-Path "$env:ProgramFiles(x86)\7-Zip\7z.exe") {
		$script:Zip = "$env:ProgramFiles(x86)\7-Zip\7z.exe"
		return
	}

	if (Test-Path "$env:SystemDrive\Yi\Yi\AIO\7z.exe") {
		$script:Zip = "$env:SystemDrive\Yi\Yi\AIO\7z.exe"
		return
	}
	$script:Zip = "No"
}

function Clear-old-file {
	remove-item -path "*.asc" -force -ErrorAction SilentlyContinue
	remove-item -path "*.sig" -force -ErrorAction SilentlyContinue
	remove-item -path "*.sha256" -force -ErrorAction SilentlyContinue
	remove-item -path "*.tar" -force -ErrorAction SilentlyContinue
	remove-item -path "*.tar.tmp" -force -ErrorAction SilentlyContinue
	remove-item -path "*.tar.xz" -force -ErrorAction SilentlyContinue
	remove-item -path "$CPSaveTo" -Recurse -force -ErrorAction SilentlyContinue
	remove-item -path "$TempFolder" -Recurse -force -ErrorAction SilentlyContinue
}

function create-7zip {
	Param(
		[string]$Type
	)

	Check-SD -chkpath $TempFolder

	switch ($Type) {
		"zip" {
			Write-Host "  * Generating $CPname.zip"
			$arguments = "a", "-tzip", "$TempFolder\$CPname.zip", "$ArchiveExclude", "*.*", "-mcu=on", "-r", "-mx9";
		}
		"tar" {
			Write-Host "  * Generating $CPname.tar"
			$arguments = "a", "$TempFolder\$CPname.tar", "$ArchiveExclude", "*.*", "-r";
		}
		"tar.xz" {
			Write-Host "  * Generating $CPname.tar.xz"
			$arguments = "a", "$TempFolder\$CPname.tar.xz", "$TempFolder\$CPname.tar", "-mf=bcj", "-mx9";
		}
		"tar.gz" {
			Write-Host "  * Generating $CPname.tar.gz"
			$arguments = "a", "-tgzip", "$TempFolder\$CPname.tar.gz", "$TempFolder\$CPname.tar", "-mx9";
		}
	}
	Start-Process $script:Zip "$arguments" -Wait -WindowStyle Minimized
	Write-Host "    - Complete`n" -ForegroundColor Green
}

function Get-SCFile {
	param($opath,$shortname,$Report)
	$fullnewpath = $opath + "." + $Report

	# Add the direct generation command to determine whether it is ASC or SHA256, and add judgment.
	Switch ($Report)
	{
		"asc" {
			Write-Host "  * Generating $CPname.asc"

			Remove-Item -Force -ErrorAction SilentlyContinue "${opath}.sig"
			Remove-Item -Force -ErrorAction SilentlyContinue "${opath}.asc"
			if ($script:secure_password) {
				Start-Process gpg -argument "--pinentry-mode loopback --passphrase $script:secure_password --local-user 0FEBF674EAD23E05 --output $opath.asc --detach-sign $opath" -Wait -WindowStyle Minimized
			} else {
				Start-Process gpg -argument "--local-user 0FEBF674EAD23E05 --output $opath.asc --detach-sign $opath" -Wait -WindowStyle Minimized
			}
			Write-Host "    - Complete`n" -ForegroundColor Green
		}
		"sha256" {
			Write-Host "  * Generating $CPname.sha256"
			$calchash = (Get-FileHash $opath -Algorithm SHA256)
			Remove-Item -Force -ErrorAction SilentlyContinue $fullnewpath
			$calchash.hash + "  " + $shortname | Out-File -FilePath $fullnewpath -Encoding ASCII
			Write-Host "    - Complete`n" -ForegroundColor Green
		}
	}
}

function Create-allfileAS {
	remove-item -path "$TempFolder\*.tar" -force

	Get-ChildItem $TempFolder -Recurse -ErrorAction SilentlyContinue | Foreach-Object {
		Get-SCFile -opath $_.FullName -shortname $_.Name -Report "asc"
		Get-SCFile -opath $_.FullName -shortname $_.Name -Report "sha256"
	}
}

function Check-SD {
	Param(
		[string]$chkpath
	)

	if(!(Test-Path $chkpath -PathType Container)) {
		New-Item -Path $chkpath -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
		if(!(Test-Path $chkpath -PathType Container)) {
			Write-Host "    - Failed to create directory: $($chkpath)`n" -ForegroundColor Red
			return
		}
	}
}

function Move-allfile {
	Check-SD -chkpath $CPSaveTo

	Get-ChildItem $TempFolder -Recurse -ErrorAction SilentlyContinue | Foreach-Object {
		Move-Item -Path $_.FullName -Destination $CPSaveTo -ErrorAction SilentlyContinue | Out-Null
	}
	remove-item -path "$TempFolder" -Recurse -force -ErrorAction SilentlyContinue
}

function Get-Mainpage {
	clear
	Write-host "
  Author: Yi ( https://fengyi.tel )

  From: Yi's Solution
  buildstring: 5.1.1.0.bk_release.210120-1208

  Mission plan:

     1. Delete old files
     2. Pack all files ( excluding exclusions )
     3. Generate $CPname ( .zip, tar.gz, tar.xz )
     4. Generate ASC signature file
     5. Generate sha256`n"

	If ($Force) {
		Clear-old-file
		create-7zip -Type "zip"
		create-7zip -Type "tar"
		create-7zip -Type "tar.xz"
		create-7zip -Type "tar.gz"
		Create-allfileAS
		Move-allfile
	} else {
		Set-Password
		Clear-old-file
		create-7zip -Type "zip"
		create-7zip -Type "tar"
		create-7zip -Type "tar.xz"
		create-7zip -Type "tar.gz"
		Create-allfileAS
		Move-allfile
		Wait-Exit -wait 6
	}
}

Get-Zip
Get-Mainpage