# Lang-php

This is a multilingual program implemented in a framework that is implemented in a number of different ways. Frame design not only allows you to build a website that is simple, fast, and efficient enough to satisfy you.

## About

* [Yi](https://fengyi.tel) - Author URI
* [lang-php](https://lang-php.com) - Lang-PHP Official Website

## FIRST USE

Thank you for choosing and using Lang-PHP to create your Web application, can benefit from long-term support and free distribution, you can also enjoy the latest Edition adds new features and BUG fixes, please visit the official website.

### SERVER

### Apple MacOS

* [MAMP](https://lang-php.com/go/MAMP) - https://bitnami.com/stack/mamp

### Microsoft Windows

* [MAMP](https://lang-php.com/go/WampServer) - http://www.wampserver.com
* [XAMPP](https://lang-php.com/go/WampServer) - https://www.apachefriends.org
* [EasyPHP](https://lang-php.com/go/EasyPHP) - http://www.easyphp.org
* [USBWebserver (Portable)](https://lang-php.com/go/USBWebserver) - http://www.usbwebserver.net

## IDE

* [Sublime Text](https://lang-php.com/go/SublimeText) - http://www.sublimetext.com
* [Aptana](https://lang-php.com/go/Aptana) - http://www.aptana.com
* [PhpStorm](https://lang-php.com/go/PhpStorm) - https://www.jetbrains.com/phpstorm
* [Cloud9](https://lang-php.com/go/Cloud9) - https://c9.io

