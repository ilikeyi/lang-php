<?php
$lpvar = array (
	'lang_page_title'    => '讀取配置文件 &amp; 加载式',
	'feature-readme'     => '自動搜索匹配嘅語言文件並加载之後調用, 包括: 字串符、參數等。',
	'lang_cfg_title'     => '配置信息',
	'lang_cfg_title1'    => '當前 Cookies 全局 "lang" 變量值: ',
	'lang_cfg_title_msg' => '未設置',
	'lang_cfg_title2'    => '瀏覽器 "HTTP_ACCEPT_LANGUAGE" 請求值: ',
	'lang_cfg_title3'    => '主題包：',
	'lang_cfg_title4'    => '語言包：03-load/languages/zh-tw.php',
	'lang_dark'          => '暗',
	'lang_dark_light'    => '亮',
	'lang_dark_save'     => '記住我',
	'lang_available'     => '可用語言',
	'lang_use_title0'    => '如何使用它',
	'lang_use_title1'    => '閱讀快速指南',
	'lang_use_title2'    => '將 "example/03-load" 目錄中的所有文件上傳到你的網站目錄；',
	'lang_use_title3'    => '瀏覽器訪問：http://&lt; 域名或 IP &gt;；',
);