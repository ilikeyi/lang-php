<?php
$lpvar = array (
	'lang_page_title'    => 'Чтение файла конфигурации &amp; Нагрузка',
	'feature-readme'     => 'Вызывается после автоматического поиска соответствия языковых файлов и загрузки, включая: string идентификатор, параметры и так далее.',
	'lang_cfg_title'     => 'Сведения о конфигурации',
	'lang_cfg_title1'    => 'Ток Cookies Глобальный "lang" Значение переменной: ',
	'lang_cfg_title_msg' => 'Не задано',
	'lang_cfg_title2'    => 'Обозреватель "HTTP_ACCEPT_LANGUAGE" Значение запроса: ',
	'lang_cfg_title3'    => 'Пакет тем: ',
	'lang_cfg_title4'    => 'Языковой пакет: 03-load/languages/ru-ru.php',
	'lang_dark'          => 'темно',
	'lang_dark_light'    => 'яркий',
	'lang_dark_save'     => 'Помни меня',
	'lang_available'     => 'Доступные языки',
	'lang_use_title0'    => 'Как его использовать',
	'lang_use_title1'    => 'Прочитайте краткое руководство',
	'lang_use_title2'    => 'воли "example/03-load" Загрузите все файлы в каталоге в каталог вашего сайта;',
	'lang_use_title3'    => 'Доступ к браузеру: http://&lt; Доменное имя или IP &gt;;',
);