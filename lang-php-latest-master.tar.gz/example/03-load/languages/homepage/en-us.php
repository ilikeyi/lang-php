<?php
$lpvar = array (
	'lang_page_title'    => 'READ THE CONFIGURATION FILE &amp; LOAD',
	'feature-readme'     => 'Called after the automatically search for matching language files and loaded, including: string identifier, parameters, and so on.',
	'lang_cfg_title'     => 'CONFIGURATION INFORMATION',
	'lang_cfg_title1'    => 'Current Cookies Global "lang" The value of the variable: ',
	'lang_cfg_title_msg' => 'Is not set',
	'lang_cfg_title2'    => 'Browser "HTTP_ACCEPT_LANGUAGE" Request value: ',
	'lang_cfg_title3'    => 'Theme pack: ',
	'lang_cfg_title4'    => 'Language Pack: 03-load/languages/en-us.php',
	'lang_dark'          => 'Dark',
	'lang_dark_light'    => 'Light',
	'lang_dark_save'     => 'Remember this',
	'lang_available'     => 'AVAILABLE LANGUAGES',
	'lang_use_title0'    => 'HOW TO USE IT',
	'lang_use_title1'    => 'Read the quick guide',
	'lang_use_title2'    => 'Upload all files in the "example/03-load" directory to your website directory;',
	'lang_use_title3'    => 'Browser access: http://&lt; domain name or IP &gt;;',
);