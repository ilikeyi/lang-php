﻿# 获取脚本参数（如果有）
[CmdletBinding()]
param(
    [parameter(Mandatory = $false, HelpMessage = "静默")]
    [Switch]$Force,
    [string]$secure_password
)

# 压缩包排除文件或目录
$ArchiveExclude = @(
    "-x!themes\Release"
    "-x!themes\docs"
    "-x!themes\downloads"
)

# 压缩包名称
$CPname = "lang-php-latest-master"

# 压缩包保存到
$CPSaveTo = "$PSScriptRoot\Release"

# 压缩包临时目录
$TempFolder = "$env:userprofile\Downloads\Temp.$CPname"

function Set-Password {
    Write-Host "`n  请输入 PGP 安全密码!`n" -ForegroundColor Green
    $script:secure_password = read-host "  证书密码"
    Write-Host ""
}

function Wait-Exit {
    param(
        [int]$wait
    )
    Write-Host "`n   提示：$wait 秒后自动退出该脚本..." -ForegroundColor Red
    Start-Sleep -s $wait
    exit
}

function Get-Zip {
	if (Test-Path "$env:ProgramFiles\7-Zip\7z.exe") {
		$script:Zip = "$env:ProgramFiles\7-Zip\7z.exe"
		return
	}

	if (Test-Path "$env:ProgramFiles(x86)\7-Zip\7z.exe") {
		$script:Zip = "$env:ProgramFiles(x86)\7-Zip\7z.exe"
		return
	}

	if (Test-Path "$env:SystemDrive\Yi\Yi\AIO\7z.exe") {
		$script:Zip = "$env:SystemDrive\Yi\Yi\AIO\7z.exe"
		return
	}
	$script:Zip = "No"
}

function Clear-old-file {
	remove-item -path "*.asc" -force -ErrorAction SilentlyContinue
	remove-item -path "*.sig" -force -ErrorAction SilentlyContinue
	remove-item -path "*.sha256" -force -ErrorAction SilentlyContinue
	remove-item -path "*.tar" -force -ErrorAction SilentlyContinue
	remove-item -path "*.tar.tmp" -force -ErrorAction SilentlyContinue
	remove-item -path "*.tar.xz" -force -ErrorAction SilentlyContinue
    remove-item -path "$CPSaveTo" -Recurse -force -ErrorAction SilentlyContinue
	remove-item -path "$TempFolder" -Recurse -force -ErrorAction SilentlyContinue
}

function create-7zip {
    Param(
        [string]$Type
    )

    if(!(Test-Path $TempFolder -PathType Container)) {
        New-Item -Path $TempFolder -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
        if(!(Test-Path $TempFolder -PathType Container)) {
            Write-Host "    - Failed to create directory: $($TempFolder)`n" -ForegroundColor Red
            return
        }
    }

    switch ($Type) {
        "zip" {
            Write-Host "  * 正在生成 $CPname.zip"
            $arguments = "a", "-tzip", "$TempFolder\$CPname.zip", "$ArchiveExclude", "*.*", "-mcu=on", "-r", "-mx9";
        }
        "tar" {
            Write-Host "  * 正在生成 $CPname.tar"
            $arguments = "a", "$TempFolder\$CPname.tar", "$ArchiveExclude", "*.*", "-r";
        }
        "tar.xz" {
            Write-Host "  * 正在生成 $CPname.tar.xz"
            $arguments = "a", "$TempFolder\$CPname.tar.xz", "$TempFolder\$CPname.tar", "-mf=bcj", "-mx9";
        }
        "tar.gz" {
            Write-Host "  * 正在生成 $CPname.tar.gz"
            $arguments = "a", "-tgzip", "$TempFolder\$CPname.tar.gz", "$TempFolder\$CPname.tar", "-mx9";
        }
    }
    Start-Process $script:Zip "$arguments" -Wait -WindowStyle Minimized
    Write-Host "    - 完成`n" -ForegroundColor Green
}

function Get-SCFile {
    param($opath,$shortname,$Report)
    $fullnewpath = $opath + "." + $Report

    # Add the direct generation command to determine whether it is ASC or SHA256, and add judgment.
    Switch ($Report)
    {
        "asc" {
            Write-Host "  * 正在生成 $CPname.asc"

            Remove-Item -Force -ErrorAction SilentlyContinue "${opath}.sig"
            Remove-Item -Force -ErrorAction SilentlyContinue "${opath}.asc"
            if ($script:secure_password) {
                Start-Process gpg -argument "--pinentry-mode loopback --passphrase $script:secure_password --local-user 0FEBF674EAD23E05 --output $opath.asc --detach-sign $opath" -Wait -WindowStyle Minimized
            } else {
                Start-Process gpg -argument "--local-user 0FEBF674EAD23E05 --output $opath.asc --detach-sign $opath" -Wait -WindowStyle Minimized
            }
            Write-Host "    - 完成`n" -ForegroundColor Green
        }
        "sha256" {
            Write-Host "  * 正在生成 $CPname.sha256"
            $calchash = (Get-FileHash $opath -Algorithm SHA256)
            Remove-Item -Force -ErrorAction SilentlyContinue $fullnewpath
            $calchash.hash + "  " + $shortname | Out-File -FilePath $fullnewpath -Encoding ASCII
            Write-Host "    - 完成`n" -ForegroundColor Green
        }
    }
}

function Create-allfileAS {
    remove-item -path "$TempFolder\*.tar" -force

    Get-ChildItem $TempFolder -Recurse -ErrorAction SilentlyContinue | Foreach-Object {
        Get-SCFile -opath $_.FullName -shortname $_.Name -Report "asc"
        Get-SCFile -opath $_.FullName -shortname $_.Name -Report "sha256"
    }
}

function Move-allfile {
    if(!(Test-Path $CPSaveTo -PathType Container)) {
        New-Item -Path $CPSaveTo -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
        if(!(Test-Path $CPSaveTo -PathType Container)) {
            Write-Host "    - Failed to create directory: $($CPSaveTo)`n" -ForegroundColor Red
            return
        }
    }

    Get-ChildItem $TempFolder -Recurse -ErrorAction SilentlyContinue | Foreach-Object {
        Move-Item -Path $_.FullName -Destination $CPSaveTo -ErrorAction SilentlyContinue | Out-Null
    }
    remove-item -path "$TempFolder" -Recurse -force -ErrorAction SilentlyContinue
}

function Get-Mainpage {
    clear
    Write-host "
  Author: Yi ( https://fengyi.tel )

  From: Yi's Solution
  buildstring: 5.1.1.0.bk_release.210120-1208

  任务计划：

     1. 删除旧文件
     2. 打包所有文件（不含排除项）
     3. 生成 $CPname ( .zip, tar.gz, tar.xz )
     4. 生成 ASC 签名文件
     5. 生成 sha256
"

	If ($Force) {
        Clear-old-file
        create-7zip -Type "zip"
        create-7zip -Type "tar"
        create-7zip -Type "tar.xz"
        create-7zip -Type "tar.gz"
        Create-allfileAS
        Move-allfile
	} else {
		$title = "您要生成发行包吗？"
		$message = "是，将生成发行包`n否，则不会生成发行包"
		$yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes", "Yes"
		$no = New-Object System.Management.Automation.Host.ChoiceDescription "&No", "No"
		$options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
		$prompt=$host.ui.PromptForChoice($title, $message, $options, 0)
			Switch ($prompt)
			{
				0 {
                    Set-Password
                    Clear-old-file
                    create-7zip -Type "zip"
                    create-7zip -Type "tar"
                    create-7zip -Type "tar.xz"
                    create-7zip -Type "tar.gz"
                    Create-allfileAS
                    Move-allfile
                    Wait-Exit -wait 6
				}
				1 {
					  Write-Host "`n   用户已取消生成。"
					  Wait-Exit -wait 2
				}
			}
	}
}

Get-Zip
Get-Mainpage