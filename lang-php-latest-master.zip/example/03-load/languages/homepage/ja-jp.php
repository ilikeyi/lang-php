<?php
$lpvar = array (
	'lang_page_title'    => '構成ファイルを読み取る &amp; ロード',
	'feature-readme'     => '後に呼び出される、自動的に言語ファイルの一致を検索、ロードを含む: 文字列の識別子、パラメーター、およびように。',
	'lang_cfg_title'     => '構成情報',
	'lang_cfg_title1'    => '現在 Cookies グローバル "lang" 変数の値: ',
	'lang_cfg_title_msg' => '設定されていません。',
	'lang_cfg_title2'    => 'ブラウザー "HTTP_ACCEPT_LANGUAGE" 要求値: ',
	'lang_cfg_title3'    => 'テーマパック：',
	'lang_cfg_title4'    => '言語パック：example/03-load/languages/ja-jp.php',
	'lang_dark'          => 'ダーク',
	'lang_dark_light'    => '明るい',
	'lang_dark_save'     => '私を覚えて',
	'lang_available'     => '利用可能な言語',
	'lang_use_title0'    => 'それを使用する方法',
	'lang_use_title1'    => 'クイックガイドを読む',
	'lang_use_title2'    => 'ウィル "example/03-load" ディレクトリ内のすべてのファイルをWebサイトディレクトリにアップロードします；',
	'lang_use_title3'    => 'ブラウザーからのアクセス: http://&lt; ドメイン名または IP &gt;；',
);