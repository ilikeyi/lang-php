<?php
$lpvar = array (
	'lang_page_title'    => '구성 파일 읽기 &amp; 부하',
	'feature-readme'     => '후는 자동으로 일치 하는 언어 파일에 대 한 검색 하 고 로드, 포함: 문자열 식별자, 매개 변수, 등등.',
	'lang_cfg_title'     => '구성 정보',
	'lang_cfg_title1'    => '전류 Cookies 글로벌 "lang" 변수 값: ',
	'lang_cfg_title_msg' => '설정 하지 않으면',
	'lang_cfg_title2'    => '브라우저 "HTTP_ACCEPT_LANGUAGE" 요청 값: ',
	'lang_cfg_title3'    => '테마 팩:',
	'lang_cfg_title4'    => '언어 팩: 03-load/languages/ko-kr.php',
	'lang_dark'          => '어두운',
	'lang_dark_light'    => '밝다',
	'lang_dark_save'     => '나를 기억해',
	'lang_available'     => '사용 가능한 언어',
	'lang_use_title0'    => '그것을 사용 하는 방법',
	'lang_use_title1'    => '빠른 안내서를 읽으십시오',
	'lang_use_title2'    => '윌 "example/03-load" 디렉토리의 모든 파일을 웹 사이트 디렉토리에 업로드하십시오.',
	'lang_use_title3'    => '브라우저 액세스: http://&lt; 도메인 이름 또는 IP &gt;;',
);