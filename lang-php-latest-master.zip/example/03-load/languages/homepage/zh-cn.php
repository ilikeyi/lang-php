<?php
$lpvar = array (
	'lang_page_title'    => '读取配置文件 &amp; 加载式',
	'feature-readme'     => '自动搜索匹配的语言文件并加载后调用，包括：字串符、参数等。',
	'lang_cfg_title'     => '配置信息',
	'lang_cfg_title1'    => '当前 Cookies 全局 "lang" 变量值：',
	'lang_cfg_title_msg' => '未设置',
	'lang_cfg_title2'    => '浏览器 "HTTP_ACCEPT_LANGUAGE" 请求值：',
	'lang_cfg_title3'    => '主题包：',
	'lang_cfg_title4'    => '语言包：03-load/languages/zh-cn.php',
	'lang_dark'          => '暗',
	'lang_dark_light'    => '亮',
	'lang_dark_save'     => '记住我',
	'lang_available'     => '可用语言',
	'lang_use_title0'    => '如何使用它',
	'lang_use_title1'    => '阅读快速指南',
	'lang_use_title2'    => '将 "example/03-load" 目錄中的所有文件上傳到你的網站目錄；',
	'lang_use_title3'    => '浏览器访问：http://&lt; 域名或 IP &gt;；',
);